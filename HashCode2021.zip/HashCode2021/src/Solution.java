import java.util.ArrayList;

import javafx.util.Pair;

public class Solution {
	public int id;
	public ArrayList<Pair<String, Integer>> result;
	
	public Solution(int id, ArrayList<Pair<String, Integer>> result) {
		this.id = id;
		this.result = result;
	}
}
