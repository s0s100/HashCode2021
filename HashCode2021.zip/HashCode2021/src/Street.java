
public class Street {
	public int fromInter;
	public int toInter;
	public String name;
	public int travelTime;
	
	public Street(int a, int b, String name, int time) {
		this.fromInter = a;
		this.toInter = b;
		this.name = name;
		this.travelTime = time;
	}
}
